<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'trailbike');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'secret');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         't9X:2SCrc^2-}-VUNX;0bgPiS+nA;g}StVZEFnnq?@nz<>w{07v(w_]!yM&2 `)v');
define('SECURE_AUTH_KEY',  'q,qBq[*h4pa}D<@Nf51(z|[3+B#+0eH^U489zUZ4xkF(#nOR-ma-C&NVdBF[n>bj');
define('LOGGED_IN_KEY',    'oshRFsfef,r T*T|c2lHM^TETOR8LYD_3(3C2W>T&&0LUt]<9K!Bv<%8OU8+3ion');
define('NONCE_KEY',        'T5+q.Xmg+DF,>:,kt|PTleia|<9YP`=Pjio=g+aK^-xMwc@Em[4+rCx/p]gh8<UO');
define('AUTH_SALT',        '0XKT6I#p$M9o}+yc|prb<2))37hZ-H:)%=I74.#cF}KR[EEHdMH59f/9sG6LQSCO');
define('SECURE_AUTH_SALT', 'qj&AQ;>fsalV-j3di<,RN,=9s7#5Tt/s[K*<07R5aLErlU+A8YC+$!tvE9za+rGG');
define('LOGGED_IN_SALT',   'o<OF<QoEM>7j 2+|`$c8EBpFG+*VcN$aO{|$GHnU9M=(p7Vuo<j$-wECH<069s0d');
define('NONCE_SALT',       'YaC;T/w|QgDNVt+Lj9[vTA,)TsMBNdY/F0-:xH}3<yF1HBX+PhMmYEq0L|NG3^Cz');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wptb_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
